
import 'package:flutter/material.dart';
import '../services/dictionary_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  List words = [];
  List filtered = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  load() async {
    words = await DictionaryService.loadDictionary();
    setState(() {
      filtered = words;
    });
  }

  search(String q) {
    setState(() {
      filtered = words.where((w) =>
          w["creole_word"].toLowerCase().contains(q.toLowerCase())
      ).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Kriolu Dictionary")),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: TextField(
              decoration: const InputDecoration(
                hintText: "Pesquisar palavra",
                border: OutlineInputBorder(),
              ),
              onChanged: search,
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filtered.length,
              itemBuilder: (context, i) {
                final w = filtered[i];
                return ListTile(
                  title: Text(w["creole_word"]),
                  subtitle: Text(w["portuguese_translation"] ?? ""),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
