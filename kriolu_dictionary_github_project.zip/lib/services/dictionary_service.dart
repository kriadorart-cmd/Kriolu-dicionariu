
import 'dart:convert';
import 'package:flutter/services.dart';

class DictionaryService {

  static Future<List> loadDictionary() async {
    final data = await rootBundle.loadString("assets/data/dictionary.json");
    return json.decode(data);
  }

}
