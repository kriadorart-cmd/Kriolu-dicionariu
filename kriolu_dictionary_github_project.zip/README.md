
# Kriolu Dictionary

Aplicação Flutter de dicionário Crioulo Cabo‑verdiano → Português.

## Funcionalidades
- Pesquisa de palavras
- Tradução crioulo → português
- Exemplos de frases
- Base de dados local JSON

## Instalar

git clone https://github.com/SEU-USUARIO/kriolu-dictionary.git
cd kriolu-dictionary
flutter pub get
flutter run
